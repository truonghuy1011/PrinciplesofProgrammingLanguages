#include "compiler.h"

namespace akan {
bool Compiler::show_char_ = false;
bool Compiler::show_token_ = false;
bool Compiler::show_symtab_ = false;
bool Compiler::show_op_ir_ = false;
bool Compiler::show_block_ = false;
bool Compiler::show_help_ = false;
bool Compiler::optim_ = false;
} // namespace akan
