#include "lexer.h"
using namespace akan;

int main() {

  Lexer::MainTest();
  return 0;
}
