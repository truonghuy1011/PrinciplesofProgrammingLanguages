#include "scanner.h"
using namespace akan;

int main() {

  Scanner::MainTest();
  return 0;
}
