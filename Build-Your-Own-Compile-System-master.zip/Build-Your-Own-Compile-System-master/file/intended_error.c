int main(){
  "love;
  int a =0x;
  /* *
}
