/*Arithmetic*/

int main() {
  int a = 1 + 2;
  int b = 3 - 4;
  int c = 5 * 6;
  int d = 7 / 8;
  return 0;
}
